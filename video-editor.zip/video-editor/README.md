# Square Video Editor (Flask + ffmpeg)

Local web app: upload a video, trim it to a start/end range, add a bold
caption (top/bottom black band, or a floating semi-transparent box), and
export a real 1:1 (1080x1080) MP4 with the trim and text permanently baked
in — not a preview trick, the exported file is actually cropped, trimmed,
and captioned.

## Setup

```bash
pip install -r requirements.txt
python app.py
```

Then open http://127.0.0.1:5050 in your browser.

## How it works

- **Upload** — the video is probed with ffprobe (duration, resolution,
  audio) and, if it's an MP4/MOV/M4V, losslessly remuxed with
  `-movflags +faststart` so the browser preview can scrub it smoothly (many
  phone-recorded videos store their index at the end of the file, which
  some browsers otherwise fail to stream).
- **Live preview** — the trim, timeline, and caption controls update an
  on-screen CSS/DOM approximation instantly, with no server round-trip.
  Play / Pause / Restart only play the selected clip range.
- **Export** — clicking "Export square video" runs one real ffmpeg pass on
  the server: trims to the exact start/end, scales+crops the source onto a
  1080x1080 canvas without distortion (same idiom as CSS `object-fit:
  cover`), and composites a Pillow-rendered caption image (real word-wrap,
  not ffmpeg's non-wrapping `drawtext`) on top. Progress shown in the UI is
  read from ffmpeg's own `-progress` output — it is the real encoding
  percentage, not a simulated timer.

## Notes

- ffmpeg/ffprobe: the app looks for both on your system PATH first. If
  `ffmpeg` isn't found, it falls back to the bundled static binary from the
  `imageio-ffmpeg` package (no manual install needed). If `ffprobe` isn't
  found anywhere, it falls back to parsing `ffmpeg -i`'s own output — less
  precise, but avoids a hard dependency on ffprobe specifically.
- Uploads and exports are kept in `uploads/` and `exports/` next to
  `app.py`; nothing is uploaded anywhere else. Feel free to delete old
  files from those folders — nothing tracks them after the app restarts.
- Minimum clip length is 0.3s; maximum caption length is 300 characters;
  max upload size is 1GB. These are easy to change at the top of `app.py`.
- Supported input formats: MP4, MOV, M4V, WEBM, MKV, AVI.
